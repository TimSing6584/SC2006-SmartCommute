import express from "express";
import * as tokenController from "../controllers/tokenController.js";

var router = express.Router();

router.get("/renew-onemap-token", tokenController.renewToken);

export default router;
