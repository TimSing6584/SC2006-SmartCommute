import express from "express";
import * as stationsController from "../controllers/stationsController.js";

var router = express.Router();

// POST /api/stations/real-time - POST stations with filtering (public)
router.post("/real-time", stationsController.realtime);

// POST /api/stations/forecast - POST forecast data (public)
router.post("/forecast", stationsController.forecast);

export default router;
