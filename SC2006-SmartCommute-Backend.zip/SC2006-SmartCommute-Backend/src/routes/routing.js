import express from "express";
import * as routingController from "../controllers/routingController.js";
import { authenticateToken } from "../middleware/auth.js";

var router = express.Router();

// GET /api/saved-routes - Get user's saved routes (requires auth)
router.get(
  "/saved-routes",
  authenticateToken,
  routingController.getSavedRoutes
);

// POST /api/save-routes - Save a new route (requires auth)
router.post(
  "/save-route",
  authenticateToken,
  routingController.createSavedRoute
);

// DELETE /api/routing/:routeId - Delete a saved route (requires auth)
router.delete(
  "/:routeId",
  authenticateToken,
  routingController.deleteSavedRoute
);

// POST /api/routing/generate-route
router.post(
  "/generate-route",
  authenticateToken,
  routingController.generateRoute
);

export default router;
