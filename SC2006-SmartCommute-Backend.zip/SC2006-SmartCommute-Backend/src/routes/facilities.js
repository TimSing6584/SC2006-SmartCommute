import express from "express";
import * as facilitiesController from "../controllers/facilitiesController.js";

var router = express.Router();

// GET /api/facilities/maintenance - get information on stations with active facilities maintenance
router.get("/maintenance", facilitiesController.maintenance);

export default router;
