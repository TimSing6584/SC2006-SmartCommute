import express from "express";
import * as alertsController from "../controllers/alertsController.js";
import { authenticateToken } from "../middleware/auth.js";

var router = express.Router();

// GET /api/alerts/live-network-summary
router.get("/live-network-summary", alertsController.getLiveNetworkSummary);

// GET /api/alerts/mrt-network-overview
router.get("/mrt-network-overview", alertsController.getMRTNetworkOverview);

export default router;
