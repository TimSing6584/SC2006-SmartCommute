import axios from "axios";
import SavedRoute from "../models/SavedRoute.js";

export const getSavedRoutes = async (req, res) => {
  try {
    const userId = req.user.userId;

    // Fetch saved routes from database
    const savedRoutes = await SavedRoute.find({ userId }).sort({
      createdAt: -1,
    });

    const updated = savedRoutes.map((doc) => {
      doc.status = "smooth";
      return doc;
    });

    console.log(updated);

    return res.status(200).json(updated);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to fetch saved routes" });
  }
};

export const createSavedRoute = async (req, res) => {
  console.log(req.body);
  try {
    const userId = req.user.userId;
    const { description, relay, route } = req.body;

    const exists = await SavedRoute.findOne({ description, userId });

    if (exists) {
      return res.status(400).json({ error: "Route already saved!" });
    }

    console.log(route);
    console.log(description);
    console.log(relay);

    // Save route to database
    const savedRoute = await SavedRoute.create({
      userId,
      route,
      description,
      relay,
    });

    return res.status(201).json(savedRoute);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to save route" });
  }
};

export const deleteSavedRoute = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { routeId } = req.params;
    console.log(routeId);

    // Delete route from database (only if user owns it)
    const deletedRoute = await SavedRoute.findOneAndDelete({
      _id: routeId,
      userId,
    });

    if (!deletedRoute) {
      return res.status(404).json({ error: "Route not found or unauthorized" });
    }

    return res.status(200).json({
      message: "Route deleted successfully",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to delete route" });
  }
};

export const generateRoute = async (req, res) => {
  const { start, end } = req.body;

  try {
    // const start = "1.32,103.84";
    // const end = "1.33,103.85";

    const now = new Date();
    const pad2 = (n) => n.toString().padStart(2, "0");

    // OneMap API expects date as MM-DD-YYYY
    const date = `${pad2(now.getMonth() + 1)}-${pad2(
      now.getDate()
    )}-${now.getFullYear()}`;

    // Time as HH:MM:SS
    const time = `${pad2(now.getHours())}:${pad2(now.getMinutes())}:${pad2(
      now.getSeconds()
    )}`;

    const url = `https://www.onemap.gov.sg/api/public/routingsvc/route?start=${encodeURIComponent(
      start
    )}&end=${encodeURIComponent(end)}&routeType=pt&date=${encodeURIComponent(
      date
    )}&time=${encodeURIComponent(time)}
    &mode=RAIL`;

    const { data } = await axios.get(url, {
      headers: {
        Authorization: process.env.ONEMAP_ACCESS_TOKEN,
      },
    });

    console.log(data);

    const plan = data.plan;
    const itineraries = plan.itineraries;

    const allPolyline = [];

    for (const itinerary of itineraries) {
      const polyline = [];

      for (const leg of itinerary.legs) {
        const mode = leg.mode;

        const from = leg.from;
        const to = leg.to;

        const geo = leg.legGeometry;
        const points = geo.points;

        polyline.push({ mode, points, from, to });
      }

      allPolyline.push(polyline);
    }

    console.log(allPolyline);

    return res.json(allPolyline).status(200);

    //
  } catch (err) {
    console.log(err.status);
    console.log(err.response);

    return res
      .status(500)
      .json({ error: "Something went wrong on the server side." });
  }
};
