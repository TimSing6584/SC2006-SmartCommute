import axios from "axios";
import fs from "fs";

const STATIONS_WITH_LOC_DATA = await import(
  "../data/sg_mrt_stations_with_loc.json",
  {
    with: { type: "json" },
  }
);

export const forecast = async (req, res) => {
  // levels -> array of possible values: "l", "m", "h"
  const { levels, codes } = req.body;

  try {
    const LTAAccountKey = process.env.LTA_ACCOUNT_KEY;

    const forecastData = [];

    for (const stationCode of codes) {
      const { data } = await axios.get(
        `https://datamall2.mytransport.sg/ltaodataservice/PCDForecast?TrainLine=${stationCode}L`,
        {
          headers: {
            AccountKey: LTAAccountKey,
          },
        }
      );

      const stations = data.value[0].Stations;

      for (const station of stations) {
        const code = station.Station;
        const crowdLevel = station.Interval[station.Interval.length - 1];

        // only further process if it matches the indicator levels filter given by the client
        if (levels.includes(crowdLevel.CrowdLevel)) {
          //
          // insert lat, lng
          //
          let latLng, name;

          for (const station of STATIONS_WITH_LOC_DATA.default) {
            if (station.codes.includes(code)) {
              latLng = {
                lat: station.lat,
                lng: station.lng,
              };

              name = station.name;

              break;
            }
          }

          //
          // push to results
          //
          forecastData.push({
            name,
            code,
            crowdLevel: crowdLevel.CrowdLevel,
            latLng,
          });
        }
      }
    }

    return res.json(forecastData).status(200);
  } catch (err) {
    console.error(err.response);
    return res
      .status(500)
      .json({ error: "Something went wrong on the server side." });
  }
};

export const realtime = async (req, res) => {
  // levels -> array of possible values: "l", "m", "h"
  const { levels, codes } = req.body;

  try {
    const LTAAccountKey = process.env.LTA_ACCOUNT_KEY;

    const realTimeData = [];

    for (const stationCode of codes) {
      const { data } = await axios.get(
        `https://datamall2.mytransport.sg/ltaodataservice/PCDRealTime?TrainLine=${stationCode}L`,
        {
          headers: {
            AccountKey: LTAAccountKey,
          },
        }
      );

      for (const station of data.value) {
        const crowdLevel = station.CrowdLevel;

        // only further process if it matches the indicator levels filter given by the client
        if (levels.includes(crowdLevel)) {
          const code = station.Station;

          //
          // insert lat, lng
          //
          let latLng, name;

          for (const station of STATIONS_WITH_LOC_DATA.default) {
            if (station.codes.includes(code)) {
              latLng = {
                lat: station.lat,
                lng: station.lng,
              };

              name = station.name;

              break;
            }
          }

          const data = {
            name,
            code,
            crowdLevel,
            latLng,
          };

          //
          // push to results
          //
          realTimeData.push(data);
        }
      }
    }

    return res.json(realTimeData).status(200);
  } catch (err) {
    console.error(err.response);

    return res
      .status(500)
      .json({ error: "Something went wrong on the server side." });
  }
};
