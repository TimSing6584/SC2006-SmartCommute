import Axios from "axios";

export const getLiveNetworkSummary = async (req, res) => {
  let summary = {
    activeLines: null,
    stationsOperational: null,
    facilitiesMaintenance: null,
    avgCrowd: null,
    lastUpdated: "Just now",
  };

  try {
    summary.activeLines = 6;

    const { data: alertData } = await Axios.get(
      "https://datamall2.mytransport.sg/ltaodataservice/TrainServiceAlerts",
      {
        headers: {
          AccountKey: process.env.LTA_ACCOUNT_KEY,
          Accept: "application/json",
        },
      }
    );

    const numAffectedSegments = alertData.value.AffectedSegments.length ?? 0;
    summary.stationsOperational = 143 - numAffectedSegments;

    const url =
      "https://datamall2.mytransport.sg/ltaodataservice/v2/FacilitiesMaintenance";

    const LTAAccountKey = process.env.LTA_ACCOUNT_KEY;

    const { data: maintenanceData } = await Axios.get(url, {
      headers: {
        AccountKey: LTAAccountKey,
      },
    });

    const numFacilitiesMaintenance = maintenanceData.value.length ?? 0;
    summary.facilitiesMaintenance = numFacilitiesMaintenance;

    summary.avgCrowd = "Low";

    return res.json(summary);

    //
  } catch (err) {
    console.log(err);
  }
};

export const getMRTNetworkOverview = async (req, res) => {
  const codes = ["CCL", "DTL", "EWL", "NEL", "NSL", "TEL"];
  const crowdLevelIndicator = {
    l: 1,
    m: 2,
    h: 3,
    NA: 0,
  };

  let levelByCodes = [
    {
      name: "NSL",
      fullName: "North-South Line",
      color: "#D42E12",
      status: null,
    },
    {
      name: "EWL",
      fullName: "East-West Line",
      color: "#009645",
      status: null,
    },
    {
      name: "NEL",
      fullName: "North-East Line",
      color: "#9900AA",
      status: null,
    },
    {
      name: "CCL",
      fullName: "Circle Line",
      color: "#FA9E0D",
      status: null,
    },
    {
      name: "DTL",
      fullName: "Downtown Line",
      color: "#005EC4",
      status: null,
    },
    {
      name: "TEL",
      fullName: "Thomson-East Coast Line",
      color: "#9D5B25",
      status: null,
    },
  ];

  const LTAAccountKey = process.env.LTA_ACCOUNT_KEY;

  try {
    for (const stationCode of codes) {
      const { data } = await Axios.get(
        `https://datamall2.mytransport.sg/ltaodataservice/PCDRealTime?TrainLine=${stationCode}`,
        {
          headers: {
            AccountKey: LTAAccountKey,
          },
        }
      );

      const stations = data.value;

      let total = 0;

      for (const station of stations) {
        total += crowdLevelIndicator[station.CrowdLevel];
      }

      const avg = total / stations.length;
      console.log(avg);

      levelByCodes = levelByCodes.map((l) => {
        if (l.name == stationCode) {
          const status = avg >= 1.5 ? "Moderate" : avg >= 2.5 ? "High" : "Low";
          return { ...l, status };

          //
        } else {
          return l;
        }
      });
    }

    return res.json(levelByCodes);
  } catch {
    return res
      .status(500)
      .json({ error: "Something went wrong on the server side." });
  }
};
