import axios from "axios";

const STATIONS_WITH_LOC_DATA = await import(
  "../data/sg_mrt_stations_with_loc.json",
  {
    with: { type: "json" },
  }
);

export const maintenance = async (_, res) => {
  try {
    const LTAAccountKey = process.env.LTA_ACCOUNT_KEY;

    const url =
      "https://datamall2.mytransport.sg/ltaodataservice/v2/FacilitiesMaintenance";

    const { data } = await axios.get(url, {
      headers: {
        AccountKey: LTAAccountKey,
      },
    });

    const results = [];

    for (const d of data.value) {
      const code = d.StationCode;
      const name = d.StationName;
      let latLng;

      for (const station of STATIONS_WITH_LOC_DATA.default) {
        if (station.codes.includes(code)) {
          latLng = {
            lat: station.lat,
            lng: station.lng,
          };

          const { LiftID, LiftDesc } = d;

          results.push({
            code,
            latLng,
            name,
            liftID: LiftID,
            liftDesc: LiftDesc,
          });

          break;
        }
      }
    }

    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Something went wrong." });
  }
};
