import Axios from "axios";

export const renewToken = async (_, res) => {
  console.log(process.env);

  try {
    const response = await Axios.post(
      `${process.env.ONEMAP_BASE_URL}/api/auth/post/getToken`,
      {
        email: process.env.ONEMAP_API_EMAIL,
        password: process.env.ONEMAP_API_PASSWORD,
      }
    );

    const accessToken = response.data.access_token;

    return res.send(accessToken);
  } catch (error) {
    console.error("Error refreshing token:", error);
    return res.status(500).send("Failed to refresh token.");
  }
};
