import mongoose, { Types } from "mongoose";

const savedRouteSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  route: {
    type: [String],
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  relay: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    default: "pending", // optional default
  },
});

export default mongoose.model("SavedRoute", savedRouteSchema);
