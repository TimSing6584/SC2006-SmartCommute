import express from "express";
import cookieParser from "cookie-parser";
import dotenv from "dotenv";
import connectDB from "./src/config/database.js";

import stationsRouter from "./src/routes/stations.js";
import facilitiesRouter from "./src/routes/facilities.js";
import authRouter from "./src/routes/auth.js";
import alertsRouter from "./src/routes/alerts.js";
import routingRouter from "./src/routes/routing.js";
import tokenRouter from "./src/routes/token.js";

const app = express();
dotenv.config();

// Connect to database
connectDB();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// CORS
app.use((_, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // your frontend
  res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  next();
});

// API routes
app.use("/api/stations", stationsRouter);
app.use("/api/auth", authRouter);
app.use("/api/facilities", facilitiesRouter);
app.use("/api/alerts", alertsRouter);
app.use("/api/routing", routingRouter);
app.use("/api/token", tokenRouter);

const port = 3000;

app.listen(port, () => {
  console.log(`SmartCommute server listening on port ${port}`);
});
