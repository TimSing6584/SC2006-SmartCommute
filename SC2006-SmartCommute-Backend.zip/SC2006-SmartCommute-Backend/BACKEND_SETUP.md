# Backend setup steps

1. Create an `.env` file in the root directory, and load with the following content:

> NOTE: the credentials are given here for the ease of testing, but should be redacted otherwise

```.env
MONGODB_URI=mongodb+srv://db-user:smartcommute@smartcommute.g3dvqlk.mongodb.net/SmartCommute?appName=SmartCommute
JWT_SECRET=smartcommute

#
# NOTE: Uncomment any of the lines for "LTA_ACCOUNT_KEY=xxxx" to change the key if any rate limiting errors are encountered
#

# LTA_ACCOUNT_KEY=Bq6uvuFnRGGDvBbR6qnTBA==
# LTA_ACCOUNT_KEY=AQ+xeEbjS8abaK9WD20ehA==
# LTA_ACCOUNT_KEY=mQ3PG+fUQ5mwopszb849Wg==
# LTA_ACCOUNT_KEY=yZqXhMPkTuuCR+G8Gq027Q==
LTA_ACCOUNT_KEY=xaXgUIQwQI+iFpMKMRg6ow==


ONEMAP_BASE_URL=https://www.onemap.gov.sg
ONEMAP_ACCESS_TOKEN=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo5OTY1LCJmb3JldmVyIjpmYWxzZSwiaXNzIjoiT25lTWFwIiwiaWF0IjoxNzYyODM1MTc4LCJuYmYiOjE3NjI4MzUxNzgsImV4cCI6MTc2MzA5NDM3OCwianRpIjoiNjc0NzJhZDEtMzkzNi00N2JiLWIyMGUtZWUxNDRmOGRjNWRjIn0.MnL6OumWq8CGM0zmzqDtGlegk5cHQG_7K9MDGJh9TLQ7ojATwky_5wOC5ZBl8N9OJryc142yTLisitZfw7H3SFCOk2ItuOFahvGO94S49uMO-E45Xqrtg2bujI2KfBjtsX0nMFm7o6hHx4793Q_1OOnL5KbHjF8kc5RGUj1EVyqheM9NeLKmK1xHN7CpCWbm0cO04kzYjRHBy8zy8PwKPXNkz8VY3stBdkZqJ-0nCrCa2vmGyHFZJgeSXwj0N7Oe9HOgkfh6Gnovy7h2C6Ut8NYYWoaU2PLjR-XYTl4ypLvQRBh65zK_Z9qHeW5hrVEpk2Wgb7khtXx3JDhb2_WNFw
```
