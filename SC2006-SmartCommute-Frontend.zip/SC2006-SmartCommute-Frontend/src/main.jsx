import { useEffect, useState } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, useLocation } from "react-router";

import localStorageUtils from "./utils/localStorageUtils.js";

import OneMapDisplay from "./components/oneMapDisplay.jsx";
import AuthenticationPage from "./components/authenticationPage.jsx";
import Dashboard from "./components/dashboard.jsx";
import FilterOptions from "./components/filterOptions.jsx";
import StationInformation from "./components/stationInformation.jsx";
import Logout from "./components/logout.jsx";
import SideNavbar from "./components/sideNavbar.jsx";

import "./css/index.css";
import "./css/main.css";
import "maplibre-gl/dist/maplibre-gl.css";
import "bootstrap/dist/css/bootstrap.min.css";

function AppRouter() {
  useEffect(() => {
    const loggedin = localStorageUtils.hasItem("user");
    setIsLoggedIn(loggedin);
  }, []);

  const [isLoggedIn, setIsLoggedIn] = useState(null);

  const location = useLocation();

  // List of routes where the navbar should NOT be displayed
  const hideNavbarRoutes = ["/auth"];

  const shouldHideNavbar = hideNavbarRoutes.includes(location.pathname);

  return (
    <>
      <Routes>
        <Route index element={<OneMapDisplay />} />
        <Route path="auth" element={<AuthenticationPage />} />
        <Route
          path="dashboard"
          element={<Dashboard isLoggedIn={isLoggedIn} />}
        />
        <Route path="filter-options" element={<FilterOptions />} />
        <Route path="station-information" element={<StationInformation />} />
        <Route path="logout" element={<Logout />} />
      </Routes>

      {/* Conditionally render the sidebar */}
      {!shouldHideNavbar && <SideNavbar isLoggedIn={isLoggedIn} />}
    </>
  );
}

const root = document.getElementById("root");

ReactDOM.createRoot(root).render(
  <BrowserRouter>
    <AppRouter />
  </BrowserRouter>
);

// createRoot(document.getElementById("root")).render(
//   <StrictMode>
//     <App />
//   </StrictMode>
// );
