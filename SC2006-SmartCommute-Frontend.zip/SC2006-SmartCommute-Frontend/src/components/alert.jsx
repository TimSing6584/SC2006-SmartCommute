import { IoIosCloseCircle } from "react-icons/io";
import "../css/alert.css";

export default function Alert({ message, onClose, icon }) {
  return (
    <div className="alert-container d-flex flex-row align-items-center gap-3">
      {icon}
      <span className="flex-1 text-sm">{message}</span>

      {onClose && (
        <div onClick={onClose} className="alert-close-container">
          <IoIosCloseCircle color="#6c63ff" size="30" />
        </div>
      )}
    </div>
  );
}
