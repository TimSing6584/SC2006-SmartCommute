import React, { useState, useEffect } from "react";
import { FaRegTrashAlt } from "react-icons/fa";

import localstorageUtils from "../utils/localStorageUtils.js";
import routingAPI from "../api/routing";
import alertsAPI from "../api/alerts.js";
import facilitiesAPI from "../api/facilities.js";

import "../css/dashboard.css";

export default function Dashboard({ isLoggedIn }) {
  const [routes, setRoutes] = useState([]);

  const [selectedLine, setSelectedLine] = useState(null);
  const [greeting, setGreeting] = useState("Good Day");
  const [facilitiesMaintenance, setFacilitiesMaintenance] = useState([]);

  const [liveSummary, setLiveSummary] = useState({
    activeLines: null,
    stationsOperational: null,
    facilitiesMaintenance: null,
    avgCrowd: null,
    lastUpdated: "Just now",
  });

  const [mrtLines, setMrtLines] = useState([]);

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting("Good Morning");
    else if (hour < 18) setGreeting("Good Afternoon");
    else setGreeting("Good Evening");
  }, []);

  useEffect(() => {
    const retrievedSavedRoutes = async () => {
      try {
        const token = localstorageUtils.getItem("token");
        const data = await routingAPI.retrieveSavedRoutesAPI(token);

        setRoutes(data);
      } catch {
        setRoutes([]);
      }
    };
    retrievedSavedRoutes();
  }, []);

  useEffect(() => {
    const getLiveNetworkSummary = async () => {
      try {
        const data = await alertsAPI.getLiveNetworkSummary();
        setLiveSummary(data);

        //
      } catch {
        setFacilitiesMaintenance([]); //clear alerts
      }
    };

    getLiveNetworkSummary();
  }, []);

  useEffect(() => {
    const getMRTNetworkOverview = async () => {
      try {
        const data = await alertsAPI.getMRTNetworkOverview();
        setMrtLines(data);

        //
      } catch {
        setFacilitiesMaintenance([]); //clear alerts
      }
    };

    getMRTNetworkOverview();
  }, []);

  useEffect(() => {
    const getFacilitiesMaintenanceData = async () => {
      const maintenanceData = [];

      try {
        const data = await facilitiesAPI.maintenanceAPI();

        for (const d of data) {
          const s = {
            type: `Lift Maintenance@${d.name}`,
            message: d.liftDesc,
            id: d.liftID ?? null,
          };

          maintenanceData.push(s);
        }

        setFacilitiesMaintenance(maintenanceData);
      } catch {
        setFacilitiesMaintenance([]);
      }
    };
    getFacilitiesMaintenanceData();
  }, []);

  const getSymbol = (status) => {
    switch (status) {
      case "Low":
        return <span className="circle green"></span>;

      case "Moderate":
        return <span className="circle orange"></span>;

      case "High":
        return <span className="circle red"></span>;

      default:
        break;
    }
  };

  const handleDeleteSavedRoute = async (e, routeId) => {
    e.stopPropagation();

    if (!window.confirm("Are you sure you want to delete the route?")) {
      return;
    }

    setRoutes((prevItems) => prevItems.filter((item) => item._id !== routeId));

    try {
      const token = localstorageUtils.getItem("token");

      await routingAPI.deleteSavedRouteAPI(routeId, token);
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="page">
      {/* Header */}
      <header className="header d-flex flex-wrap row-gap-2">
        <h1>{greeting}, Commuter</h1>

        {/* <label className="accessibility-toggle">
          <input
            type="checkbox"
            checked={accessibilityMode}
            onChange={() => setAccessibilityMode(!accessibilityMode)}
          />
          <span className="slider me-2" />
          <span className="toggle-label">Accessibility Mode</span>
        </label> */}
      </header>

      {/* Live Network Summary */}
      <section className="live-summary">
        <h2>Live Network Summary</h2>
        <div className="summary-grid">
          <div className="summary-card">
            <h3>Active MRT Lines</h3>
            <p>{liveSummary.activeLines}</p>
          </div>
          <div className="summary-card">
            <h3>Stations Operational</h3>
            <p>{liveSummary.stationsOperational}</p>
          </div>
          <div className="summary-card">
            <h3>Lifts Under Maintenance</h3>
            <p>{liveSummary.facilitiesMaintenance}</p>
          </div>
          <div className="summary-card">
            <h3>Average Crowd Level</h3>
            <p>{liveSummary.avgCrowd}</p>
          </div>
        </div>
        <p className="summary-update">
          Last updated: {liveSummary.lastUpdated}
        </p>
      </section>

      {/* MRT Network Overview */}
      <section className="network-overview">
        <h2>MRT Network Overview</h2>
        <div className="line-grid">
          {mrtLines.map((line) => (
            <div
              key={line.name}
              className={`line-card ${
                selectedLine === line.name ? "active" : ""
              }`}
              style={{ borderColor: line.color }}
              onClick={() => setSelectedLine(line.name)}
            >
              <h3 style={{ color: line.color }}>{line.name}</h3>
              <p>{line.fullName}</p>
              <div className="status-symbol">{getSymbol(line.status)}</div>
            </div>
          ))}
        </div>

        {selectedLine && (
          <div className="popup-overlay" onClick={() => setSelectedLine(null)}>
            <div className="popup" onClick={(e) => e.stopPropagation()}>
              <h3>{mrtLines.find((l) => l.name === selectedLine).fullName}</h3>
              <p>
                Crowd level:{" "}
                <strong
                  style={{
                    color:
                      mrtLines.find((l) => l.name === selectedLine).status ===
                      "Low"
                        ? "#22c55e"
                        : mrtLines.find((l) => l.name === selectedLine)
                            .status === "Moderate"
                        ? "Orange"
                        : "#ef4444",
                  }}
                >
                  {mrtLines.find((l) => l.name === selectedLine).status}
                </strong>
              </p>

              <button onClick={() => setSelectedLine(null)}>Close</button>
            </div>
          </div>
        )}
      </section>

      {/* Routes */}
      {isLoggedIn ? (
        <div className=" row">
          {/* My Commute */}
          <section className="my-commute col-12 col-md-8">
            <h2>Your saved routes</h2>
            <div className="route-list">
              {routes.length === 0 ? (
                <p className="no-alerts">No saved routes</p>
              ) : (
                routes.map((route) => (
                  <div
                    className="route"
                    key={route._id}
                    onClick={() => {
                      localstorageUtils.setItem("route", route.route);
                      window.location.href = "/";
                    }}
                  >
                    <div className="route-info">
                      <h3 className="route-title">{route.description}</h3>
                      <p className="route-details">{route.relay}</p>
                    </div>
                    <span
                      className={`status ${
                        route.status.includes("Delay")
                          ? "delay"
                          : route.status.includes("Breakdown")
                          ? "breakdown"
                          : "smooth"
                      }`}
                    >
                      {route.status}
                    </span>

                    <div
                      className="ps-2"
                      onClick={(e) => handleDeleteSavedRoute(e, route._id)}
                    >
                      <FaRegTrashAlt color="#8B0000" />
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

          {/* Alerts Section */}
          <div className="col-12 col-md-4">
            <aside className="alerts me-2">
              <h2>Active alerts</h2>
              {facilitiesMaintenance.map((alert, idx) => (
                <div
                  key={idx}
                  className={`alert-card ${
                    alert.type.includes("Lift Maintenance")
                      ? "lift"
                      : "disruption"
                  }`}
                >
                  <h4>{alert.type}</h4>
                  <p>{alert.message}</p>

                  {alert.id ? (
                    <span className="alert-id">{"ID: " + alert.id}</span>
                  ) : null}
                </div>
              ))}
            </aside>
          </div>
        </div>
      ) : null}
    </div>
  );
}
