import { useState } from "react";
import { Link } from "react-router";
import { IoMdAlert } from "react-icons/io";
import { FaInfoCircle } from "react-icons/fa";

import localStorageUtils from "../utils/localStorageUtils.js";

import Alert from "./alert";
import authAPI from "../api/auth.js";

import "../css/authentication.css";

export default function AuthenticationPage() {
  const [alert, setAlert] = useState("");
  const [isErr, setIsErr] = useState(false);

  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
  });

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    setIsErr(false);
    e.preventDefault();

    const { email, password, confirmPassword } = formData;

    try {
      if (!isLogin) {
        // Handle signup only
        if (password !== confirmPassword) {
          setIsErr(true);
          setAlert("Passwords don't match!");
          return;
        }

        // call API
        const data = await authAPI.registerAPI(email, password);
        console.log(data);

        setIsLogin(true);

        setAlert(
          "You have successfully created an account, you can now login with your entered credentials."
        );
      } else {
        // call API
        const data = await authAPI.loginAPI(email, password);
        console.log(data);

        window.location.replace("/");

        localStorageUtils.setItem("user", data.user);
        localStorageUtils.setItem("token", data.token);
      }
    } catch (err) {
      setIsErr(true);
      setAlert(err.msg);
    }
  };

  return (
    <div className="auth-container">
      {alert != "" ? (
        <Alert
          message={alert}
          onClose={() => setAlert("")}
          icon={
            isErr ? (
              <IoMdAlert color="red" size="22" />
            ) : (
              <FaInfoCircle color="blue" size="40" />
            )
          }
        />
      ) : null}

      <div className="auth-card">
        <div className="auth-header">
          <h1>SmartCommute</h1>
          <p>Your intelligent MRT companion</p>
        </div>

        <div className="auth-tabs">
          <button
            className={`tab ${isLogin ? "active" : ""}`}
            onClick={() => setIsLogin(true)}
          >
            Login
          </button>
          <button
            className={`tab ${!isLogin ? "active" : ""}`}
            onClick={() => setIsLogin(false)}
          >
            Sign Up
          </button>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              required
              placeholder="Enter your email"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              required
              placeholder="Enter your password"
            />
          </div>

          {!isLogin && (
            <div className="form-group">
              <label htmlFor="confirmPassword">Confirm Password</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                required={!isLogin}
                placeholder="Confirm your password"
              />
            </div>
          )}

          <button type="submit" className="auth-button">
            {isLogin ? "Login" : "Create Account"}
          </button>
        </form>

        <div className="auth-footer">
          <Link to="/" className="back-link">
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
