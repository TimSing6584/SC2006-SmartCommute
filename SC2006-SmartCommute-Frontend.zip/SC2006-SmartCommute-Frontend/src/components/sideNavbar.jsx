import { FaMapMarkerAlt } from "react-icons/fa";
import { MdDashboard } from "react-icons/md";
import { FiLogIn } from "react-icons/fi";
// import { FiLogOut } from "react-icons/fi";
import { CgLogOut } from "react-icons/cg";

import "../css/sideNavbar.css";

export default function SideNavbar({ isLoggedIn }) {
  return (
    <div className="sidebar">
      <div className="logo-box">
        <img
          src="train-icon.jpg"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
          }}
        />
      </div>

      <div className="w-100">
        <ul className="sidebar-icons">
          <li className="icon-item">
            <a href="/" className="icon-anchor d-flex justify-content-center">
              <span className="inner-icon-container p-2 d-flex justify-content-center align-items-center">
                <FaMapMarkerAlt className="icon-logo" />
              </span>
              <span className="icon-info">Home</span>
            </a>
          </li>
          <li className="icon-item">
            <a
              href="/dashboard"
              className="icon-anchor d-flex justify-content-center"
            >
              <span className="inner-icon-container p-2 d-flex justify-content-center align-items-center">
                <MdDashboard className="icon-logo" />
              </span>

              <span className="icon-info">Dashboard</span>
            </a>
          </li>
          <li className="icon-item">
            {isLoggedIn !== null &&
              (isLoggedIn ? (
                <a
                  href="/logout"
                  className="icon-anchor d-flex justify-content-center"
                  onClick={(e) => {
                    if (!window.confirm("Are you sure you want to logout?")) {
                      e.preventDefault();
                    }
                  }}
                >
                  <span className="inner-icon-container p-2 d-flex justify-content-center align-items-center">
                    <CgLogOut className="icon-logo" />
                  </span>

                  <span className="icon-info">Logout</span>
                </a>
              ) : (
                <a
                  href="/auth"
                  className="icon-anchor d-flex justify-content-center"
                >
                  <div className="p-1">
                    <span className="inner-icon-container p-2 d-flex justify-content-center align-items-center">
                      <FiLogIn className="icon-logo" />
                    </span>
                  </div>
                  <span className="icon-info">Login</span>
                </a>
              ))}
          </li>
        </ul>
      </div>
    </div>
  );
}
