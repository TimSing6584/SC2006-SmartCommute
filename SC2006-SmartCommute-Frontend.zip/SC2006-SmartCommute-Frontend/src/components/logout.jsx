import { useEffect } from "react";

import localStorageUtils from "../utils/localStorageUtils";

function Logout() {
  useEffect(() => {
    localStorageUtils.removeItem("user");
    localStorageUtils.removeItem("token");

    window.location.replace("/");
  }, []);

  return null; // don't render anything
}

export default Logout;
