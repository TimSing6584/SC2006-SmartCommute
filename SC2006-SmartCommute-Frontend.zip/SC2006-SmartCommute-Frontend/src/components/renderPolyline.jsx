import { useEffect } from "react";
import L from "leaflet";
import polyline from "@mapbox/polyline";

function RenderPolyline({ mapRef, data }) {
  useEffect(() => {
    mapRef.current.eachLayer((layer) => {
      // Remove only LineString layers (polyline & multi-polyline)
      if (layer instanceof L.Polyline && !(layer instanceof L.Polygon)) {
        mapRef.current.removeLayer(layer);
      }
    });

    if (!mapRef.current || !data || data.length === 0) return;

    console.log("data");
    console.log(data);

    const d = data[0];

    for (const p of d) {
      const mode = p.mode;
      const coords = polyline.decode(p.points);

      const latlngs = coords.map((c) => [c[0], c[1]]);

      let color;

      switch (mode) {
        case "WALK":
          color = "red";
          break;

        case "BUS":
          color = "green";
          break;

        case "SUBWAY":
          color = "blue";
          break;

        default:
          break;
      }

      L.polyline(latlngs, { color }).addTo(mapRef.current);
    }
  }, [mapRef, data]);

  return null;
}

export default RenderPolyline;
