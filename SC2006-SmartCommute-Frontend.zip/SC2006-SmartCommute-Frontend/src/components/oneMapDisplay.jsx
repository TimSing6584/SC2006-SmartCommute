import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import { IoSearch } from "react-icons/io5";
import { MdFilterListAlt } from "react-icons/md";
import { HiOutlineLocationMarker } from "react-icons/hi";
import { IoIosCloseCircle } from "react-icons/io";
import { FaTrainSubway } from "react-icons/fa6";
import { IoClose } from "react-icons/io5";
import { MdError } from "react-icons/md";

import stationsAPI from "../api/stations.js";
import facilitiesAPI from "../api/facilities.js";
import routingAPI from "../api/routing.js";

import localstorageUtils from "../utils/localStorageUtils.js";

import Alert from "./alert.jsx";
import StationInformation from "./stationInformation.jsx";
import FilterOptions from "./filterOptions.jsx";
import RenderPolyline from "./renderPolyline.jsx";

import FILTERS_CONFIG from "../config/filters.json";

import "leaflet/dist/leaflet.css";
import "../css/oneMapDisplay.css";

function OneMapDisplay() {
  const mapRef = useRef(null);
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [shouldDisplayStationInformation, setShouldDisplayStationInformation] =
    useState(false);
  const [shouldDisplayFilterOptions, setShouldDisplayFilterOptions] =
    useState(false);

  const [stationInformationData, setStationInformationData] = useState({
    code: "",
    name: "",
    realtimeCrowdLevel: "",
    forecastCrowdLevel: "",
    maintenance: {
      liftID: "",
      liftDesc: "",
    },
  });

  const [compiledData, setCompiledData] = useState([]);
  const [realTimeCrowdData, setRealTimeCrowdData] = useState([]);
  const [forecastCrowdData, setForecastCrowdData] = useState([]);
  const [facilitiesMaintenanceData, setFacilitiesMaintenanceData] = useState(
    []
  );

  const [searchboxResults, setSearchboxResults] = useState([]);
  const [routingSearchboxResults, setRoutingSearchboxResults] = useState([]);
  const [routingInputFor, setRoutingInputFor] = useState(null);
  const [routingPolyline, setRoutingPolyline] = useState([]);

  const [shouldRenderRoutingWindow, setShouldRenderRoutingWindow] =
    useState(false);
  const [routingStart, setRoutingStart] = useState({
    name: "",
    lat: null,
    lng: null,
  });
  const [routingEnd, setRoutingEnd] = useState({
    name: "",
    lat: null,
    lng: null,
  });

  const [isErr, setIsErr] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (mapRef.current && isMapLoaded) {
      return;
    }

    const displaySavedRoutes = async () => {
      const route = localstorageUtils.getItem("route");
      const token = localstorageUtils.getItem("token");

      if (!route) return;

      const data = await routingAPI.generateRouteAPI(route[0], route[1], token);

      console.log(data);
      handleDisplayRoutesOnMap(data);

      // remove saved routes in local storage
      localstorageUtils.removeItem("route");
    };
    displaySavedRoutes();
  }, [isMapLoaded]);

  useEffect(() => {
    console.log(compiledData);
  }, [compiledData]);

  const loadRealtimeCrowdData = async (levels, codes) => {
    try {
      const data = await stationsAPI.realtimeAPI(levels, codes);

      setRealTimeCrowdData(data);

      data.forEach((d) => {
        setCompiledData((cur) => {
          const index = cur.findIndex((t) => t.code === d.code);

          if (index > -1) {
            // Found -> replace entry with updated copy
            return cur.map((item, i) =>
              i === index ? { ...item, realtimeCrowdLevel: d.crowdLevel } : item
            );
          } else {
            // Not found -> return new array with new entry appended
            return [
              ...cur,
              {
                code: d.code,
                name: d.name,
                realtimeCrowdLevel: d.crowdLevel,
                LATITUDE: d.latLng.lat,
                LONGITUDE: d.latLng.lng,
              },
            ];
          }
        });
      });
    } catch (err) {
      setIsErr(true);

      if (err.status == 500) {
        setMsg(
          'Something went wrong, it appears that either the "real-time crowd level" API provider is undergoing maintenance, or quota limit has been reached. Please try again later, thank you.'
        );
      } else {
        setMsg("Something went wrong, please try again later.");
      }
    }
  };

  const loadForecastCrowdData = async (levels, codes) => {
    try {
      const data = await stationsAPI.forecastAPI(levels, codes);

      setForecastCrowdData(data);

      data.forEach((d) => {
        setCompiledData((cur) => {
          const index = cur.findIndex((t) => t.code === d.code);

          if (index > -1) {
            // Found -> replace entry with updated copy
            return cur.map((item, i) =>
              i === index ? { ...item, forecastCrowdLevel: d.crowdLevel } : item
            );
          } else {
            // Not found -> return new array with new entry appended
            return [
              ...cur,
              {
                code: d.code,
                name: d.name,
                forecastCrowdLevel: d.crowdLevel,
                LATITUDE: d.latLng.lat,
                LONGITUDE: d.latLng.lng,
              },
            ];
          }
        });
      });
    } catch (err) {
      setIsErr(true);

      if (err.status == 500) {
        setMsg(
          'Something went wrong, it appears that either the "forecast crowd level" API provider is undergoing maintenance, or quota limit has been reached. Please try again later, thank you.'
        );
      } else {
        setMsg("Something went wrong, please try again later.");
      }
    }
  };

  const loadFacilitiesMaintenanceData = async () => {
    try {
      const data = await facilitiesAPI.maintenanceAPI();

      setFacilitiesMaintenanceData(data);

      data.forEach((d) => {
        setCompiledData((cur) => {
          const index = cur.findIndex((t) => t.code === d.code);

          if (index > -1) {
            // Found -> replace entry with updated copy
            return cur.map((item, i) =>
              i === index
                ? {
                    ...item,
                    liftMaintenance: { liftID: d.liftID, liftDesc: d.liftDesc },
                  }
                : item
            );
          } else {
            // Not found -> return new array with new entry appended
            return [
              ...cur,
              {
                code: d.code,
                name: d.name,
                liftMaintenance: { liftID: d.liftID, liftDesc: d.liftDesc },
              },
            ];
          }
        });
      });
    } catch (err) {
      setIsErr(true);

      if (err.status == 500) {
        setMsg(
          err.msg
            ? err.msg
            : "Upstream API provider is currently ungoing maintenance for realtime data, please try again later."
        );
      } else {
        setMsg("Something went wrong, please try again later.");
      }
    }
  };

  // initial load of data from API
  useEffect(() => {
    const r = localstorageUtils.getItem("route");

    if (r) return;

    const loadData = async () => {
      await loadRealtimeCrowdData(
        ["l", "m", "h"],
        FILTERS_CONFIG.defaultStationCodesToFilter
      );
      await loadForecastCrowdData(
        ["l", "m", "h"],
        FILTERS_CONFIG.defaultStationCodesToFilter
      );
    };
    loadData();
  }, []);

  useEffect(() => {
    const sw = L.latLng(1.144, 103.535);
    const ne = L.latLng(1.494, 104.502);
    const bounds = L.latLngBounds(sw, ne);

    // Fetch TileJSON from OneMap
    fetch(
      "https://www.onemap.gov.sg/maps/json/raster/tilejson/2.2.0/GreyLite.json"
    )
      .then((res) => res.json())
      .then((data) => {
        // create the map
        mapRef.current = L.map("mapdiv", {
          minZoom: data.minzoom,
          maxZoom: 18,
          zoomControl: false,
          // maxBounds: [
          //   [1.1443, 103.596],
          //   [1.4835, 104.1],
          // ],
          maxBoundsViscosity: 1.0,
        });

        // map loaded!
        setIsMapLoaded(true);

        // add TileJSON layer
        L.tileLayer(data.tiles[0], {
          attribution:
            '<img src="https://www.onemap.gov.sg/web-assets/images/logo/om_logo.png" style="height:20px;width:20px;"/>&nbsp;<a href="https://www.onemap.gov.sg/" target="_blank" rel="noopener noreferrer">OneMap</a>&nbsp;&copy;&nbsp;contributors&nbsp;&#124;&nbsp;<a href="https://www.sla.gov.sg/" target="_blank" rel="noopener noreferrer">Singapore Land Authority</a>',
        }).addTo(mapRef.current);

        mapRef.current.fitBounds(bounds);
        mapRef.current.setView([1.33, 103.83], 12.5);

        // Listen to panning events
        mapRef.current.on("move", () => {
          handleRemoveFilterOptions();
          setShouldDisplayStationInformation(false);
        });
      });
  }, [compiledData]);

  useEffect(() => {
    if (facilitiesMaintenanceData.length > 0) return;

    let marker;

    if (mapRef.current && isMapLoaded) {
      console.log("RESET");
      // reset markers
      mapRef.current.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          mapRef.current.removeLayer(layer);
        }
      });

      const customIcon = L.divIcon({
        html: '<div class="marker-train-div"><img src="train.svg" class="marker-train-img"/></div>',
        iconSize: [32, 32], // width, height
      });

      const stationCodesAddedToMap = [];

      for (const r of realTimeCrowdData) {
        const latLng = r.latLng;

        if (
          typeof latLng.lat === "undefined" ||
          typeof latLng.lng === "undefined"
        ) {
          continue;
        }

        marker = L.marker([latLng.lat, latLng.lng], { icon: customIcon }).addTo(
          mapRef.current
        );

        stationCodesAddedToMap.push(r.code);

        // on click event
        marker.addEventListener("click", () => {
          // r["type"] = "realtime";

          const found = compiledData.find((c) => c.code == r.code);

          setStationInformationData(found);
          setShouldDisplayStationInformation(true);
        });
      }

      console.log(stationCodesAddedToMap);

      for (const f of forecastCrowdData) {
        if (stationCodesAddedToMap.includes(f.code)) continue;

        const latLng = f.latLng;

        if (
          typeof latLng.lat === "undefined" ||
          typeof latLng.lng === "undefined"
        ) {
          continue;
        }

        marker = L.marker([latLng.lat, latLng.lng], { icon: customIcon }).addTo(
          mapRef.current
        );

        // on click event
        marker.addEventListener("click", () => {
          const found = compiledData.find((c) => c.code == f.code);

          setStationInformationData(found);
          setShouldDisplayStationInformation(true);
        });
      }
    }
  }, [
    isMapLoaded,
    realTimeCrowdData,
    forecastCrowdData,
    compiledData,
    facilitiesMaintenanceData,
  ]);

  useEffect(() => {
    let marker;

    if (mapRef.current && isMapLoaded && facilitiesMaintenanceData.length > 0) {
      // reset markers
      mapRef.current.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          mapRef.current.removeLayer(layer);
        }
      });

      for (const f of facilitiesMaintenanceData) {
        const latLng = f.latLng;

        if (
          typeof latLng.lat === "undefined" ||
          typeof latLng.lng === "undefined"
        ) {
          continue;
        }

        const customIcon = L.divIcon({
          html: '<div class="marker-tools-div"><img src="tools.svg" class="marker-tools-img"/></div>',
          iconSize: [32, 32], // width, height
        });

        marker = L.marker([latLng.lat, latLng.lng], {
          icon: customIcon,
        }).addTo(mapRef.current);

        // on click event
        marker.addEventListener("click", () => {
          const found = compiledData.find((c) => c.code == f.code);

          setStationInformationData(found);
          setShouldDisplayStationInformation(true);
        });
      }
    }
  }, [isMapLoaded, compiledData, facilitiesMaintenanceData]);

  const handleDisplayFilterOptions = () => {
    setShouldDisplayFilterOptions(true);
  };

  const handleRemoveFilterOptions = () => {
    setShouldDisplayFilterOptions(false);
  };

  const handleStationCodesToFilterChange = async (
    stationCodesToFilter,
    realtimeFilter,
    forecastFilter
  ) => {
    setShouldDisplayStationInformation(false);

    await loadRealtimeCrowdData(realtimeFilter, stationCodesToFilter);
    await loadForecastCrowdData(forecastFilter, stationCodesToFilter);
  };

  const handleCrowdLevelFilterChange = async (
    type,
    state,
    stationCodesToFilter
  ) => {
    setShouldDisplayStationInformation(false);

    switch (type) {
      case "realtime":
        {
          await loadRealtimeCrowdData(state, stationCodesToFilter);
        }

        break;

      case "forecast":
        {
          await loadForecastCrowdData(state, stationCodesToFilter);
        }

        break;

      default:
        break;
    }
  };

  const handleSingleOptionFilterChange = async (type, state) => {
    setShouldDisplayStationInformation(false);

    if (type === "maintenance") {
      if (state) {
        // call facilities maintenance API
        await loadFacilitiesMaintenanceData();
      } else {
        setFacilitiesMaintenanceData([]);
      }
    }
  };

  const handleResetSearchBox = () => {
    setSearchboxResults([]);

    document.getElementById("searchBox").value = "";
  };

  const handleDisplayRoutingWindow = (start) => {
    setShouldRenderRoutingWindow(true);

    setRoutingStart(start);
  };

  const handleSearchboxResultsSelection = (loc) => {
    handleResetSearchBox();

    const lat = parseFloat(loc.LATITUDE);
    const lng = parseFloat(loc.LONGITUDE);

    // reset markers
    mapRef.current.eachLayer((layer) => {
      if (layer instanceof L.Marker) {
        mapRef.current.removeLayer(layer);
      }
    });

    const customIcon = L.divIcon({
      html:
        loc.type === "station"
          ? '<div class="marker-train-div"><img src="train.svg" class="marker-train-img"/></div>'
          : '<div class="marker-loc-div"><img src="marker.svg" class="marker-loc-img"/></div>',
      iconSize: [32, 32], // width, height
    });

    // create marker for address
    const marker = L.marker([lat, lng], {
      icon: customIcon,
    }).addTo(mapRef.current);

    // mapRef.current.setView([lat, lng], 16);

    if (loc.type === "station") {
      marker.addEventListener("click", () => {
        //
        // to render on information window
        //
        const found = compiledData.find((c) => c.code == loc.code);

        setStationInformationData(found);
        setShouldDisplayStationInformation(true);
      });

      //
      // to render routing window
      //

      handleDisplayRoutingWindow({
        name: loc.name,
        lat: loc.LATITUDE,
        lng: loc.LONGITUDE,
      });
    }
  };

  const handleSearchboxInputEventListener = async () => {
    setSearchboxResults([]);

    // search box
    const searchBox = document.getElementById("searchBox");

    const query = searchBox.value;

    //
    // (1) Filter station
    //

    const found = compiledData.filter((c) =>
      c.name.toLowerCase().includes(query.toLowerCase())
    );

    if (typeof found !== "undefined") {
      setSearchboxResults((cur) => [
        ...cur,
        ...found.map((item) => ({
          ...item,
          value: item.name,
          type: "station",
          code: item.code,
        })),
      ]);
    }
  };

  const handleRoutingInput = async (e, type) => {
    setRoutingSearchboxResults([]);
    setRoutingInputFor(type);

    const input = e.target.value;

    if (type === "start") {
      setRoutingStart((cur) => {
        return { ...cur, name: input };
      });
    } else {
      setRoutingEnd((cur) => {
        return { ...cur, name: input };
      });
    }

    try {
      const found = compiledData.filter((c) =>
        c.name.toLowerCase().includes(input.toLowerCase())
      );

      if (typeof found !== "undefined") {
        setRoutingSearchboxResults((cur) => [
          ...cur,
          ...found.map((item) => ({
            ...item,
            value: item.name,
            type: "station",
            code: item.code,
          })),
        ]);
      }

      //
    } catch (err) {
      console.log(err);

      setIsErr(true);
      setMsg("Failed to search.");
    }
  };

  const handleRoutingSearchboxResultsSelection = (loc) => {
    console.log(loc);

    const { name, LATITUDE, LONGITUDE } = loc;

    if (routingInputFor === "start") {
      setRoutingStart({
        name,
        lat: LATITUDE,
        lng: LONGITUDE,
      });
    } else {
      setRoutingEnd({
        name,
        lat: LATITUDE,
        lng: LONGITUDE,
      });

      const customIcon = L.divIcon({
        html:
          loc.type === "station"
            ? '<div class="marker-train-div"><img src="train.svg" class="marker-train-img"/></div>'
            : '<div class="marker-loc-div"><img src="marker.svg" class="marker-loc-img"/></div>',
        iconSize: [32, 32], // width, height
      });

      const marker = L.marker([LATITUDE, LONGITUDE], {
        icon: customIcon,
      }).addTo(mapRef.current);

      marker.addEventListener("click", () => {
        //
        // to render on information window
        //
        const found = compiledData.find((c) => c.code == loc.code);

        setStationInformationData(found);
        setShouldDisplayStationInformation(true);
      });
    }
  };

  const handleDisplayRoutesOnMap = (data) => {
    setRoutingPolyline(data);

    if (data.length > 0) {
      // reset markers
      mapRef.current.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
          mapRef.current.removeLayer(layer);
        }
      });

      for (const d of data[0]) {
        const from = d.from;
        const to = d.to;

        const customIcon = L.divIcon({
          html: '<div class="marker-loc-div"><img src="marker.svg" class="marker-loc-img"/></div>',
          iconSize: [32, 32], // width, height
        });

        if (from.name !== "Origin") {
          const fromMarker = L.marker([from.lat, from.lon], {
            icon: customIcon,
          }).addTo(mapRef.current);

          fromMarker.addEventListener("click", () => {
            setStationInformationData({
              relay: true,
              name: from.name,
            });
            setShouldDisplayStationInformation(true);
          });
        }

        if (to.name !== "Destination") {
          const toMarker = L.marker([to.lat, to.lon], {
            icon: customIcon,
          }).addTo(mapRef.current);

          toMarker.addEventListener("click", () => {
            setStationInformationData({
              relay: true,
              name: to.name,
            });
            setShouldDisplayStationInformation(true);
          });
        }
      }
    }
  };

  const handleRoutingSearch = async () => {
    try {
      if (!routingStart.lat || !routingEnd.lat) {
        setIsErr(true);
        setMsg("Start or end location missing!");
        return;
      }

      const start = `${routingStart.lat},${routingStart.lng}`;
      const end = `${routingEnd.lat},${routingEnd.lng}`;

      // setRoutingStartLatLng(start);
      // setRoutingEndLatLng(end);

      const token = localstorageUtils.getItem("token");

      const data = await routingAPI.generateRouteAPI(start, end, token);
      console.log(data);

      handleDisplayRoutesOnMap(data);

      return [start, end, data];

      //
    } catch (err) {
      console.log(err);

      setIsErr(true);

      switch (err.status) {
        // forbidden
        case 403:
          setMsg("Please login to use the routing search feature, thank you!");
          break;

        case 500:
          setMsg(
            err.msg
              ? err.msg
              : "It appears that there was an issue with retrieving the location for the station, please try another station name."
          );

          break;

        default:
          setMsg(
            "It appears that there was an issue with retrieving the location for the station, please try another station name."
          );
          break;
      }
    }
  };

  const handleGenerateRoute = (code) => {
    const m = compiledData.find((c) => c.code == code);

    const { name, LATITUDE, LONGITUDE } = m;

    const d = {
      name,
      lat: LATITUDE,
      lng: LONGITUDE,
    };

    handleDisplayRoutingWindow(d);
  };

  const handleSaveRoute = async () => {
    const [routingStartLatLng, routingEndLatLng, routingPolyline] =
      await handleRoutingSearch();

    const token = localstorageUtils.getItem("token");

    try {
      const route = [routingStartLatLng, routingEndLatLng];
      const description = `${routingStart.name} → ${routingEnd.name}`;

      let relay = "";
      let i = 0;

      console.log(routingPolyline[0]);

      for (const r of routingPolyline[0]) {
        if (r.mode == "WALK") {
          i++;
          continue;
        }

        if (i == 0) {
          relay += routingStart.name;

          i++;
          continue;
        } else if (i == routingPolyline[0].length - 1) {
          relay += relay === "" ? routingEnd.name : " → " + routingEnd.name;

          i++;
          continue;
        } else {
          const from = r.from.name;
          const to = r.to.name;

          relay += relay.includes(from)
            ? " → " + to
            : relay === ""
            ? `${from} → ${to}`
            : ` → ${from} → ${to}`;
        }

        i++;
      }

      console.log(relay);
      await routingAPI.saveRouteAPI(description, relay, route, token);

      setMsg("Successfully saved the route!");
    } catch (err) {
      setIsErr(true);

      console.log(err);

      switch (err.status) {
        case 400:
          setMsg(err.msg);
          break;

        // forbidden
        case 403:
          setMsg("Please login to use the routing search feature, thank you!");
          break;

        case 500:
          setMsg(
            err.msg
              ? err.msg
              : "It appears that there was an issue with retrieving the location for the station, please try another station name."
          );

          break;

        default:
          setMsg(
            "It appears that there was an issue with retrieving the location for the station, please try another station name."
          );
          break;
      }
    }
  };

  const handleCloseRoutingWindow = () => {
    setRoutingSearchboxResults([]);
    setRoutingInputFor(null);
    setRoutingPolyline([]);
    setShouldRenderRoutingWindow(false);
  };

  useEffect(() => {
    console.log(routingStart);
    console.log(routingEnd);
    console.log(routingSearchboxResults);
  }, [routingStart, routingEnd, routingSearchboxResults]);

  return (
    <div>
      {msg != "" ? (
        <Alert
          icon={isErr ? <MdError color="red" size="25" /> : null}
          message={msg}
          onClose={() => {
            setMsg("");
            setIsErr(false);
          }}
        />
      ) : null}

      <div className="d-flex flex-column position-absolute main-filter-search-overlay-container">
        <div className="d-flex flex-row gap-2">
          <div className="d-flex align-items-center">
            {/* FILTER OPTIONS */}
            <div
              className="d-flex justify-content-center align-items-center filter-options-icon-container"
              onClick={
                shouldDisplayFilterOptions
                  ? handleRemoveFilterOptions
                  : handleDisplayFilterOptions
              }
            >
              <MdFilterListAlt
                style={{
                  width: "1.6rem",
                  height: "1.6rem",
                }}
              />
            </div>
          </div>

          <div className="search-box-container d-flex flex-row gap-2">
            <div className="d-flex justify-content-center align-items-center search-box-icon">
              <IoSearch />
            </div>

            <input
              type="text"
              id="searchBox"
              placeholder="Search for a location"
              className="search-box"
              onSelect={handleSearchboxInputEventListener}
              onChange={handleSearchboxInputEventListener}
            />

            <div
              className="searchbox-close-div d-flex justify-content-center align-items-center search-box-icon"
              onClick={handleResetSearchBox}
            >
              <IoIosCloseCircle />
            </div>
          </div>
        </div>

        <FilterOptions
          shouldDisplay={shouldDisplayFilterOptions}
          onCrowdlevelChange={handleCrowdLevelFilterChange}
          onSingleOptionChange={handleSingleOptionFilterChange}
          onStationCodesToFilterChange={handleStationCodesToFilterChange}
          onClose={() => setShouldDisplayFilterOptions(false)}
        />

        {/* search box results */}
        {searchboxResults.length > 0 ? (
          <div className="search-box-results">
            <ul>
              <li className="fw-bold">
                *Note that the search results will only return stations that is
                part of the current filter
              </li>

              {searchboxResults.map((s, i) => (
                <li
                  key={i}
                  className="d-flex flex-row gap-2 m-2"
                  onClick={() => handleSearchboxResultsSelection(s)}
                >
                  <div>
                    {s.type === "location" ? (
                      <HiOutlineLocationMarker color="#6c63ff" />
                    ) : (
                      <FaTrainSubway color="#EB663F" />
                    )}
                  </div>
                  {s.value}
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        {shouldRenderRoutingWindow ? (
          <div className="routing-container">
            {/* routing window */}
            <div className="routing-window p-4 gap-4 d-flex flex-column">
              <div
                className="routing-window-close-icon position-absolute"
                onClick={handleCloseRoutingWindow}
              >
                <IoClose size={20} />
              </div>

              <div>
                Routing path colors:{" "}
                <span className="fw-bold" style={{ color: "red" }}>
                  WALK
                </span>
                {", "}
                <span className="fw-bold" style={{ color: "blue" }}>
                  SUBWAY
                </span>
              </div>

              <div className="row">
                <div className="fw-bold col-2">Start</div>

                <div className="col-10">
                  <input
                    type="text"
                    placeholder="Start station name"
                    className="routing-search-box"
                    onSelect={(e) => handleRoutingInput(e, "start")}
                    onChange={(e) => handleRoutingInput(e, "start")}
                    value={routingStart.name}
                  />
                </div>
              </div>

              <div className="row">
                <div className="fw-bold col-2">End</div>

                <div className="col-10">
                  <input
                    type="text"
                    placeholder="End station name"
                    className="routing-search-box"
                    onSelect={(e) => handleRoutingInput(e, "end")}
                    onChange={(e) => handleRoutingInput(e, "end")}
                    value={routingEnd.name}
                  />
                </div>
              </div>

              <button className="routing-button" onClick={handleRoutingSearch}>
                Search
              </button>

              <button className="save-route-button" onClick={handleSaveRoute}>
                Save route
              </button>
            </div>

            {/* ROUTING search box results */}
            {routingSearchboxResults.length > 0 ? (
              <div className="routing-search-box-results">
                <ul>
                  {routingSearchboxResults.map((s, i) => (
                    <li
                      key={i}
                      className="d-flex flex-row gap-2 m-2"
                      onClick={() => handleRoutingSearchboxResultsSelection(s)}
                    >
                      <div>
                        <FaTrainSubway color="#EB663F" />
                      </div>
                      {s.value}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        ) : null}
      </div>

      <StationInformation
        shouldDisplay={shouldDisplayStationInformation}
        onClose={() => setShouldDisplayStationInformation(false)}
        data={stationInformationData}
        onGenerateRoute={handleGenerateRoute}
        shouldAllowRouting={!(facilitiesMaintenanceData.length > 0)}
      />

      <div
        id="mapdiv"
        style={{
          height: "100vh",
          width: "100vw",
        }}
      />

      {mapRef.current ? (
        <RenderPolyline mapRef={mapRef} data={routingPolyline} />
      ) : null}
    </div>
  );
}

export default OneMapDisplay;
