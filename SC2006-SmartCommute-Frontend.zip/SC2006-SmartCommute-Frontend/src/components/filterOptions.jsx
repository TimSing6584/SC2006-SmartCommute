import { useState, useEffect } from "react";

import { IoClose } from "react-icons/io5";

import CROWD_LEVEL_INDICATOR_DATA from "../data/crowd-level-indicators.json";
import STATION_CODES_DATA from "../data/station-codes.json";
import FILTERS_CONFIG from "../config/filters.json";

import "../css/filterOptions.css";

const FilterOptions = ({
  shouldDisplay,
  onCrowdlevelChange,
  onSingleOptionChange,
  onStationCodesToFilterChange,
  onClose,
}) => {
  const [stationCodesToFilter, setStationCodesToFilter] = useState(
    FILTERS_CONFIG.defaultStationCodesToFilter
  );
  const [realTimeCrowd, setRealTimeCrowd] = useState(
    FILTERS_CONFIG.defaultRealTimeCrowd
  );
  const [forecastCrowd, setForecastCrowd] = useState(
    FILTERS_CONFIG.defaultForecastCrowd
  );
  const [liftMaintenance, setLiftMaintenance] = useState(false);
  // const [serviceInterruption, setServiceInterruption] = useState();

  useEffect(() => {
    const el = document.getElementById("filters-container");

    if (!shouldDisplay) {
      el.classList.remove("show");
    } else {
      el.classList.add("show");
    }
  }, [shouldDisplay]);

  const resetFilters = () => {
    setStationCodesToFilter(FILTERS_CONFIG.defaultStationCodesToFilter);
    setRealTimeCrowd(FILTERS_CONFIG.defaultRealTimeCrowd);
    setForecastCrowd(FILTERS_CONFIG.defaultForecastCrowd);
    setLiftMaintenance(false);
    // setServiceInterruption(false);

    onCrowdlevelChange(
      "realtime",
      FILTERS_CONFIG.defaultRealTimeCrowd,
      FILTERS_CONFIG.defaultStationCodesToFilter
    );
    onCrowdlevelChange(
      "forecast",
      FILTERS_CONFIG.defaultForecastCrowd,
      FILTERS_CONFIG.defaultStationCodesToFilter
    );
    onSingleOptionChange("maintenance", false, stationCodesToFilter);
  };

  const handleCrowdlevelChange = (type, curState, setState, level) => {
    let newState;

    if (curState.includes(level)) {
      // remove
      newState = curState.filter((item) => item !== level);
    } else {
      // add
      newState = [...curState, level];
    }

    setState(newState);

    // callback function
    onCrowdlevelChange(type, newState, stationCodesToFilter);
  };

  const renderCrowdlevelCheckbox = (type, label, state, setState) => (
    <div
      className="filter-group"
      style={{
        opacity: liftMaintenance ? 0.4 : 1,
      }}
    >
      <div className="filter-label">{label}</div>
      <div className="checkboxes">
        {["l", "m", "h"].map((key) => (
          <label key={key}>
            <input
              type="checkbox"
              checked={state.includes(key)}
              onChange={() =>
                handleCrowdlevelChange(type, state, setState, key)
              }
            />
            {CROWD_LEVEL_INDICATOR_DATA[key]}
          </label>
        ))}
      </div>
    </div>
  );

  const handleSingleOptionChange = (key, curState, setState) => {
    const newState = !curState;
    setState(newState);

    // callback function
    onSingleOptionChange(key, newState, stationCodesToFilter);
  };

  const renderSingleOption = (key, label, state, setState) => (
    <div className="filter-group">
      <div className="filter-label">{label}</div>
      <p>
        *Note that when this option is active, it will overwrite all the other
        filters
      </p>

      <label className="d-flex align-items-center gap-1">
        Yes
        <input
          type="checkbox"
          checked={state}
          onChange={() => handleSingleOptionChange(key, state, setState)}
        />
      </label>
    </div>
  );

  const handleStationCodesFilterChange = (code) => {
    let cur;

    if (stationCodesToFilter.includes(code)) {
      // Remove item
      cur = stationCodesToFilter.filter((el) => el !== code);
    } else {
      // Add item

      cur = [...stationCodesToFilter, code];
    }

    if (cur.length > 2) {
      return;
    }

    setStationCodesToFilter(cur);
    onStationCodesToFilterChange(cur, realTimeCrowd, forecastCrowd);
  };

  return (
    <div id="filters-container" className="filters-container">
      <div className="close-icon position-absolute" onClick={onClose}>
        <IoClose size={20} />
      </div>

      <div className="m-2 d-flex flex-column gap-3">
        {/* STATION CODES FILTER */}
        <div
          className="filter-group"
          style={{
            opacity: liftMaintenance ? 0.4 : 1,
          }}
        >
          <div className="filter-label">Station codes (*max 2 at once)</div>

          <div className="d-flex flex-wrap gap-2">
            {STATION_CODES_DATA.map((code) => (
              <div className="checkboxes" key={code}>
                <label>
                  <input
                    type="checkbox"
                    checked={stationCodesToFilter.includes(code)}
                    onChange={() => handleStationCodesFilterChange(code)}
                  />
                  {code}
                </label>
              </div>
            ))}
          </div>
        </div>

        {renderCrowdlevelCheckbox(
          "realtime",
          "Real-time crowd levels",
          realTimeCrowd,
          setRealTimeCrowd
        )}
        {renderCrowdlevelCheckbox(
          "forecast",
          "Crowd Forecast",
          forecastCrowd,
          setForecastCrowd
        )}
        {renderSingleOption(
          "maintenance",
          "Only display lifts under maintenance",
          liftMaintenance,
          setLiftMaintenance
        )}
        {/* {renderSingleOption(
        "Service Interruption",
        serviceInterruption,
        setServiceInterruption
      )} */}

        <button className="reset-button fw-bold" onClick={resetFilters}>
          Reset filters
        </button>
      </div>
    </div>
  );
};

export default FilterOptions;
