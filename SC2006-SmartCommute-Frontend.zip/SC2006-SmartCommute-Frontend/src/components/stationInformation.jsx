import { useEffect } from "react";
import { IoClose } from "react-icons/io5";
import { FaMapMarkerAlt } from "react-icons/fa";

import STATION_CODE_TO_COLOR from "../data/station-code-to-color.json";
import CROWD_LEVEL_INDICATORS from "../data/crowd-level-indicators.json";

import "../css/stationInformation.css";

const StatusItem = ({ level }) => (
  <div className="status-item">
    {/* The status dot: applies base class and specific color class */}
    <div
      className="status-dot"
      aria-hidden="true"
      style={{
        backgroundColor:
          level == CROWD_LEVEL_INDICATORS["l"]
            ? "#35F527"
            : level == CROWD_LEVEL_INDICATORS["m"]
            ? "orange"
            : "red",
      }}
    />
    <span>{level}</span>
  </div>
);

const StationInformation = ({
  shouldDisplay,
  onClose,
  data,
  onGenerateRoute,
  shouldAllowRouting,
}) => {
  useEffect(() => {
    const el = document.getElementById("info-card");

    if (!el) return;

    if (!shouldDisplay) {
      el.classList.remove("show");
    } else {
      el.classList.add("show");
    }
  }, [shouldDisplay]);

  return (
    <>
      {typeof data.relay !== "undefined" && data.relay ? (
        <div id="info-card" className="info-card">
          <div className="close-icon position-absolute" onClick={onClose}>
            <IoClose size={20} />
          </div>

          <div className="d-flex flex-row gap-2 p-1">
            <FaMapMarkerAlt size="20" color="#6c63ff" />

            <h2 className="station-name">{data.name}</h2>
          </div>
        </div>
      ) : (
        <div id="info-card" className="info-card">
          <div className="close-icon position-absolute" onClick={onClose}>
            <IoClose size={20} />
          </div>
          <h1 className="main-title">Station Information</h1>
          {/* Station Header (Code and Name) */}
          <div className="station-header">
            {/* Code Tag */}
            <span
              className="station-code"
              style={{
                backgroundColor:
                  STATION_CODE_TO_COLOR[
                    data.code.toUpperCase().replace(/\d+$/, "")
                  ],
              }}
            >
              {data.code}
            </span>
            {/* Station Name */}
            <h2 className="station-name">{data.name}</h2>
          </div>
          {/* Service Status */}
          {/* <div className="service-status">
        <p className="section-title" style={{ marginBottom: "4px" }}>
          {stationData.serviceStatus}
        </p>
      </div> */}
          {/* Current Crowd Level */}
          {typeof data.realtimeCrowdLevel !== "undefined" ? (
            <div className="crowd-section">
              <p className="section-title">Current crowd level</p>
              <StatusItem
                level={CROWD_LEVEL_INDICATORS[data.realtimeCrowdLevel]}
              />
            </div>
          ) : null}
          {/* Crowd Forecast */}
          {typeof data.forecastCrowdLevel !== "undefined" ? (
            <div className="crowd-section">
              <p className="section-title">Crowd forecast (next 30 mins)</p>
              <StatusItem
                level={CROWD_LEVEL_INDICATORS[data.forecastCrowdLevel]}
              />
            </div>
          ) : null}
          {/* Lift Availability */}
          {typeof data.liftMaintenance !== "undefined" ? (
            <div>
              <p className="section-title">Lift maintenance</p>
              <p className="lift-availability-text d-flex flex-column">
                {data.liftMaintenance.liftDesc}
                {data.liftMaintenance.liftID !== ""
                  ? "(ID:" + data.liftMaintenance.liftID + ")"
                  : null}
              </p>
            </div>
          ) : null}

          {/* Routing */}
          {shouldAllowRouting ? (
            <button
              className="generate-route-button"
              onClick={() => onGenerateRoute(data.code)}
            >
              Generate route
            </button>
          ) : null}
        </div>
      )}
    </>
  );
};

export default StationInformation;
