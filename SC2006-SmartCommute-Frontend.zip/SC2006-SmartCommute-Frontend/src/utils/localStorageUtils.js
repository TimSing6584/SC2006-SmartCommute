/**
 * Save a value to localStorage.
 * @param {string} key - Storage key
 * @param {any} value - Value to store (object/array/string/number)
 */
function setItem(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/**
 * Retrieve a value from localStorage.
 * @param {string} key - Storage key
 * @returns {any|null} - Parsed value or null if key not found
 */
function getItem(key) {
  const stored = localStorage.getItem(key);
  if (!stored) return null;

  try {
    return JSON.parse(stored);
  } catch (err) {
    console.error("Failed to parse localStorage value:", err);
    return null;
  }
}

/**
 * Check if a key exists in localStorage
 * @param {string} key - Storage key
 * @returns {boolean} - True if exists, false if not
 */
function hasItem(key) {
  return localStorage.getItem(key) !== null;
}

/**
 * Remove an item from localStorage
 * @param {string} key - The key to remove
 */
function removeItem(key) {
  localStorage.removeItem(key);
}

export default { setItem, getItem, hasItem, removeItem };
