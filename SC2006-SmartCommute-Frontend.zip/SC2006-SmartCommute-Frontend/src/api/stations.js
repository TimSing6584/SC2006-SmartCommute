import Axios from "axios";
import API_DATA from "../config/api.json";

const realtimeAPI = async (state, codes) => {
  try {
    const { data } = await Axios.post(API_DATA.url + "/stations/real-time", {
      levels: state,
      codes,
    });

    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

const forecastAPI = async (state, codes) => {
  try {
    const { data } = await Axios.post(API_DATA.url + "/stations/forecast", {
      levels: state,
      codes,
    });

    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

export default { realtimeAPI, forecastAPI };
