import Axios from "axios";
import API_DATA from "../config/api.json";

const generateRouteAPI = async (start, end, token) => {
  try {
    const { data } = await Axios.post(
      API_DATA.url + "/routing/generate-route",
      {
        start,
        end,
      },
      {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      }
    );

    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

const saveRouteAPI = async (description, relay, route, token) => {
  try {
    const { data } = await Axios.post(
      API_DATA.url + "/routing/save-route",
      {
        route,
        description,
        relay,
      },
      {
        headers: {
          Authorization: "Bearer " + token,
          "Content-Type": "application/json",
        },
      }
    );
    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

const retrieveSavedRoutesAPI = async (token) => {
  try {
    const { data } = await Axios.get(API_DATA.url + "/routing/saved-routes", {
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
    });
    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

const deleteSavedRouteAPI = async (routeId, token) => {
  try {
    const { data } = await Axios.delete(API_DATA.url + `/routing/${routeId}`, {
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
    });
    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

export default {
  generateRouteAPI,
  saveRouteAPI,
  retrieveSavedRoutesAPI,
  deleteSavedRouteAPI,
};
