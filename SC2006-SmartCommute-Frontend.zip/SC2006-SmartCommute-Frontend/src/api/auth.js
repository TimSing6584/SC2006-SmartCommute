import Axios from "axios";
import API_DATA from "../config/api.json";

const registerAPI = async (email, password) => {
  try {
    const { data } = await Axios.post(API_DATA.url + "/auth/register", {
      email,
      password,
    });

    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

const loginAPI = async (email, password) => {
  try {
    const { data } = await Axios.post(API_DATA.url + "/auth/login", {
      email,
      password,
    });

    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

export default { registerAPI, loginAPI };
