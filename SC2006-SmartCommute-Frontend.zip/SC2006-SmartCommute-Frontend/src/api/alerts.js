import Axios from "axios";
import API_DATA from "../config/api.json";

const getLiveNetworkSummary = async () => {
  try {
    const { data } = await Axios.get(
      API_DATA.url + "/alerts/live-network-summary"
    );

    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

const getMRTNetworkOverview = async () => {
  try {
    const { data } = await Axios.get(
      API_DATA.url + "/alerts/mrt-network-overview"
    );

    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

export default { getLiveNetworkSummary, getMRTNetworkOverview };
