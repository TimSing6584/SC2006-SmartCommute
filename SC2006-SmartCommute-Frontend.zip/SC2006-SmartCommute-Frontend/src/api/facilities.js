import Axios from "axios";
import API_DATA from "../config/api.json";

const maintenanceAPI = async () => {
  try {
    const { data } = await Axios.get(API_DATA.url + "/facilities/maintenance");

    return data;

    //
  } catch (err) {
    throw {
      status: err.response.status,
      msg: err.response.data.error,
    };
  }
};

export default { maintenanceAPI };
